A Pen created at CodePen.io. You can find this one at https://codepen.io/Mariok18/pen/mQrLYv.

 A simple note app using W3.CSS. Made use of the search filter and modals.